# Scripts Bash - Exercices

Ce dossier contient 5 scripts Bash correspondant aux exercices demandés.

## Contenu

1. **count_files.sh**  
   Compte le nombre de fichiers dans un répertoire donné.  
   **Utilisation** : `./count_files.sh mon_dossier`

2. **find_string.sh**  
   Recherche une chaîne de caractères dans un fichier texte.  
   **Utilisation** : `./find_string.sh fichier.txt chaine`

3. **cli_arguments.sh**  
   Affiche chaque argument fourni, un par ligne.  
   **Utilisation** : `./cli_arguments.sh arg1 arg2 ...`

4. **show_disk_usage.sh**  
   Affiche l'utilisation du disque (globale et dossier courant).  
   **Utilisation** : `./show_disk_usage.sh`

5. **simple_calculator.sh**  
   Calculette simple : effectue une opération sur deux entiers.  
   **Utilisation** : `./simple_calculator.sh 5 3 +`

## Instructions

- Rends les scripts exécutables si besoin :  
  `chmod +x *.sh`
- Exécute-les avec Bash ou directement s'ils sont exécutables.

## Auteur

Scripts générés automatiquement pour la pratique Bash.
